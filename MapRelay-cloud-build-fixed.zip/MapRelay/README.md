# Map Relay 0.1

A minimal native Android share-target prototype. It receives shared plain text and forwards it to the Tesla app, then Waze, intending to leave Waze in the foreground.

## Build an APK using GitHub Actions

This project includes `.github/workflows/build-apk.yml`.

1. Create a **private** repository on GitHub (for example, `map-relay`).
2. Upload the contents of this `MapRelay` folder to the repository root. Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab. If prompted, enable workflows.
4. The workflow runs on the first push to `main`. Wait for **Build Map Relay APK** to finish successfully.
5. Open the completed workflow run, scroll to **Artifacts**, and download `MapRelay-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.

The APK is a debug build signed with GitHub Actions' temporary Android debug key. It is suitable for testing, not Play Store distribution. Keep the repository private and do not upload personal credentials or signing keys.

## Prototype behaviour and limitations

- Receives Android `ACTION_SEND` text shares.
- Forwards the received text to Tesla (`com.teslamotors.tesla`) first, then Waze (`com.waze`).
- No network permission, account credentials, API key, background service, contacts, location, SMS, or storage permissions are declared by this app.
- This behaviour has **not** yet been verified on a physical phone. Android/app launch behaviour can vary; test with a non-critical destination first.
- Google Maps may share a shortened `maps.app.goo.gl` link. This prototype forwards the original text unchanged, matching the manual sharing flow the user has confirmed works.

## Project details

- App label: Map Relay
- Package: `com.example.maprelay`
- Minimum Android: API 26
- Target/compile SDK: 35
