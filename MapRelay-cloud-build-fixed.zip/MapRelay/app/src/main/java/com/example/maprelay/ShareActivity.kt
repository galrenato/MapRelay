package com.example.maprelay

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/**
 * Receives Google Maps' Android share intent and forwards the same payload to
 * Tesla first, then Waze. Launching Waze last is intentional: it should remain
 * the foreground app while Tesla receives the destination in the background.
 */
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        forwardShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        forwardShare(intent)
    }

    private fun forwardShare(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) {
            finish()
            return
        }

        val text = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            ?: incoming.data?.toString()

        if (text.isNullOrBlank()) {
            Toast.makeText(this, "No destination text received", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val subject = incoming.getStringExtra(Intent.EXTRA_SUBJECT)
        val htmlText = incoming.getStringExtra(Intent.EXTRA_HTML_TEXT)

        // Tesla first: its share receiver normally confirms delivery without
        // taking over the screen. Waze is launched afterwards and stays visible.
        val teslaSent = launchShareTarget(
            packageName = TESLA_PACKAGE,
            text = text,
            subject = subject,
            htmlText = htmlText
        )

        val wazeSent = launchShareTarget(
            packageName = WAZE_PACKAGE,
            text = text,
            subject = subject,
            htmlText = htmlText
        )

        if (!wazeSent) {
            val message = if (teslaSent) {
                "Sent to Tesla, but Waze could not be opened"
            } else {
                "Could not open Waze or Tesla. Check that both apps are installed."
            }
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        } else if (!teslaSent) {
            Toast.makeText(this, "Waze opened; Tesla could not receive the destination", Toast.LENGTH_LONG).show()
        }

        finish()
    }

    private fun launchShareTarget(
        packageName: String,
        text: String,
        subject: String?,
        htmlText: String?
    ): Boolean {
        val outgoing = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            setPackage(packageName)
            putExtra(Intent.EXTRA_TEXT, text)
            if (!subject.isNullOrBlank()) putExtra(Intent.EXTRA_SUBJECT, subject)
            if (!htmlText.isNullOrBlank()) putExtra(Intent.EXTRA_HTML_TEXT, htmlText)
        }

        return try {
            startActivity(outgoing)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    companion object {
        // Official Android package IDs used by the installed apps.
        private const val TESLA_PACKAGE = "com.teslamotors.tesla"
        private const val WAZE_PACKAGE = "com.waze"
    }
}
